import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

enum ExportStatus { success, failure, dismissed }

class ExportResult {
  final ExportStatus status;
  final String? filePath;
  final String? errorMessage;

  const ExportResult._({
    required this.status,
    this.filePath,
    this.errorMessage,
  });

  factory ExportResult.success(String filePath) =>
      ExportResult._(status: ExportStatus.success, filePath: filePath);

  factory ExportResult.failure(String message) =>
      ExportResult._(status: ExportStatus.failure, errorMessage: message);

  factory ExportResult.dismissed() =>
      const ExportResult._(status: ExportStatus.dismissed);

  bool get isSuccess => status == ExportStatus.success;
}

class ExportService {
  Future<Uint8List?> captureAsPng({
    required GlobalKey boundaryKey,
    double pixelRatio = 3.0,
  }) async {
    try {
      final RenderRepaintBoundary boundary = boundaryKey.currentContext!
          .findRenderObject() as RenderRepaintBoundary;
      final ui.Image image = await boundary.toImage(pixelRatio: pixelRatio);
      final ByteData? byteData =
          await image.toByteData(format: ui.ImageByteFormat.png);
      return byteData?.buffer.asUint8List();
    } catch (e) {
      debugPrint('[ExportService] captureAsPng failed: $e');
      return null;
    }
  }

  Future<String?> saveToTempFile(Uint8List pngBytes) async {
    try {
      final Directory tempDir = await getTemporaryDirectory();
      final String fileName =
          'liveink_${DateTime.now().millisecondsSinceEpoch}.png';
      final File file = File('${tempDir.path}/$fileName');
      await file.writeAsBytes(pngBytes);
      return file.path;
    } catch (e) {
      debugPrint('[ExportService] saveToTempFile failed: $e');
      return null;
    }
  }

  Future<String?> saveToDocuments(Uint8List pngBytes) async {
    try {
      final Directory docsDir = await getApplicationDocumentsDirectory();
      final String fileName =
          'liveink_${DateTime.now().millisecondsSinceEpoch}.png';
      final File file = File('${docsDir.path}/$fileName');
      await file.writeAsBytes(pngBytes);
      return file.path;
    } catch (e) {
      debugPrint('[ExportService] saveToDocuments failed: $e');
      return null;
    }
  }

  Future<ExportResult> shareDrawing({
    required GlobalKey boundaryKey,
    double pixelRatio = 3.0,
  }) async {
    final Uint8List? pngBytes =
        await captureAsPng(boundaryKey: boundaryKey, pixelRatio: pixelRatio);
    if (pngBytes == null) return ExportResult.failure('Failed to capture canvas');

    final String? filePath = await saveToTempFile(pngBytes);
    if (filePath == null) return ExportResult.failure('Failed to save file');

    final XFile xFile = XFile(filePath, mimeType: 'image/png');
    final ShareResult result = await SharePlus.instance.share(
      ShareParams(
        files: [xFile],
        text: 'Check out my drawing made with LiveInk!',
      ),
    );

    if (result.status == ShareResultStatus.success) {
      return ExportResult.success(filePath);
    } else if (result.status == ShareResultStatus.dismissed) {
      return ExportResult.dismissed();
    } else {
      return ExportResult.failure('Share was not completed');
    }
  }

  Future<ExportResult> saveDrawing({
    required GlobalKey boundaryKey,
    double pixelRatio = 3.0,
  }) async {
    final Uint8List? pngBytes =
        await captureAsPng(boundaryKey: boundaryKey, pixelRatio: pixelRatio);
    if (pngBytes == null) return ExportResult.failure('Failed to capture canvas');

    final String? filePath = await saveToDocuments(pngBytes);
    if (filePath == null) return ExportResult.failure('Failed to save file');

    return ExportResult.success(filePath);
  }
}
